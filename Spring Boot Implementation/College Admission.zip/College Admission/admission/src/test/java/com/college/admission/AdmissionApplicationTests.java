package com.college.admission;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdmissionApplicationTests {

	@Test
	void contextLoads() {
	}

}
